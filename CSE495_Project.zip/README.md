Here is Attached the Project Report paper and
the Ipython notebook to "RUN ALL models test and train"

#TOTAL FILE SIZE is more than  30 GB !!! SO we cannot give the files in Mail 
We could have given the Codes Scripts but everying was written for Run in COLAB so we are Giving The Shared Folder in the Mail as a link 

JUST click the link and go to your SHARED WITH ME FOLDER and ADD To My Drive 

To Run The Source .py or ipynb Files Follow the instructions written in runmeforallwork.ipynb  

and then we can easily test and also train our 3 implementions Of Our NLP Project . 

So What we have done so far !! 
1.LSTM Model
2.RNN Model
3.GPT-2 Model

to run all the files Requirements are 

keras
numpy 
matplotlib 
fire>=0.1.3
regex==2017.4.5
requests==2.21.0
tqdm==4.31.1
toposort==1.5
tensorflow ==>1.2

Submitted by group Members

Md.Sajid Ahmed -1610364042 
Arifuzzaman Arman  -1610551042
Zahin Akram 1610618042
Md Rakib Imtiaz - 1610294642
